force-quit
==========

Gnome Shell Extension to add Force Quit Button

About
=====

Adds a force quit button.

On accidental click, right click or press [ESC] to undo.

Customize position by tweaking line 50 of extension.js


Tip
=====

Right-click anywhere or click on the top panel to abort the kill.

Installation
============

Install it from the [extensions site](https://extensions.gnome.org/extension/770/force-quit/)
